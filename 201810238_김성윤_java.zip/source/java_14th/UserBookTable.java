package swing;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.table.DefaultTableModel;

public class UserBookTable {
	
	ON o = new ON();
	Book B = new Book();
	ConnectUser CU = new ConnectUser();
	public void insertUserBook(String ptr) {		//user�� ���� å ���Ը޼ҵ�
		
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null; 
		
		try {
			con = Connect.getConnect();
			stmt = con.createStatement();
			String sql = "update javaUser set book = '"+ptr+"' where id = '"+o.id+"' ";
			stmt.executeUpdate(sql);
			
			
			} catch (SQLException e) {
				System.out.println("insertUserBook SQL ���� = " + e.getMessage());
			} finally {
				Connect.close(con, stmt,rs);
			}
		}
	public void updateState(int num ,String title) {		//������ �뿩���ϰ� ���¸� 1�� ������Ʈ
		
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null; 
		
		try {
			con = Connect.getConnect();
			stmt = con.createStatement();
			String sql = "update javaBook set state = '"+num+"' where title = '"+title+"'";
			stmt.executeUpdate(sql);
			
			
			} catch (SQLException e) {
				System.out.println("insertUserBook SQL ���� = " + e.getMessage());
			} finally {
				Connect.close(con, stmt,rs);
			}
		}
	
	public String[] getUserBook() {
		
		
		Connect connect = new Connect();
		Connection con = null;
		Statement stmt = null;
		ResultSet rs =null;
		
		String bookname = null;
		String[] array = null;

		try {
			con = Connect.getConnect();
			stmt = con.createStatement();
			String sql = "select book from javaUser where id = '"+o.id+"'";
			rs= stmt.executeQuery(sql);
			while(rs.next()) {
				 bookname = rs.getString("book");
			}
			array = bookname.split("��");
			} catch (SQLException e) {
				System.out.println("SQL ���� = " + e.getMessage());
				
			} finally {
				Connect.close(con, stmt,rs);
			}
		return array;
		
		}
	void ViewUserTable(String[] array) {
		
		
		Connect connect = new Connect();
		Connection con = null;
		Statement stmt = null;
		ResultSet rs =null;
		int n = CU.countSpNum();
		Book.rentNum.setText(o.name+"�� �뿩���ɱǼ� :"+(6-n));
		
		
		DefaultTableModel Bmodel = (DefaultTableModel)Book.Utable.getModel();
		Bmodel.setNumRows(0);
		
		try {
			con = Connect.getConnect();
			
			stmt = con.createStatement();

			for (int i=0;i<array.length;i++) {
				rs = stmt.executeQuery("select * from javaBook where title = '"+array[i]+"'");
				while (rs.next()) {
					int num = rs.getInt("num");
					String title = rs.getString("title");
					String author = rs.getString("author");
					String genre = rs.getString("genre");
					Vector rowData = new Vector();  //insert
					rowData.add(num);
					rowData.add(title);
					rowData.add(author);
					rowData.add(genre);
					
					B.Udtm.addRow(rowData);
					
				}	
			}
			} catch (SQLException e) {
				System.out.println("SQL ���� = " + e.getMessage());
			} finally {
				Connect.close(con, stmt,rs);
			}
		
	}
	String returnBookName() {
		
		Connect connect = new Connect();
		Connection con = null;
		Statement stmt = null;
		ResultSet rs =null;
		String book = null;
		try {
			con = Connect.getConnect();
			stmt = con.createStatement();
			String sql = "select book from javaUser where id = '"+o.id+"'";
			rs= stmt.executeQuery(sql);
			while(rs.next()) {
				 book = rs.getString("book");
			}
			
			} catch (SQLException e) {
				System.out.println("SQL ���� = " + e.getMessage());
				
			} finally {
				Connect.close(con, stmt,rs);
			}
		return book;
		
		}
}
