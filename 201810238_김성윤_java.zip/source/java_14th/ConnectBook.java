package swing;


import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectBook {
	
	public void BookInput(int num,String title,String author,String genre) {    // Book insert
		Connection con = null;
		Statement stmt = null;
		ResultSet rs =null;
		
		try {
			con = Connect.getConnect();
			stmt = con.createStatement();
			String sql = "insert into javaBook value('"+num+"','"+title+"','"+author+"','"+genre+"',0);";
			stmt.executeUpdate(sql);
			} catch (SQLException e) {
				System.out.println("SQL ���� = " + e.getMessage());
			} finally {
				Connect.close(con, stmt,rs);
			}
		}
	public void updateBook(int num,int cnum,String title,String author,String genre) {    // Book insert
		Connection con = null;
		Statement stmt = null;
		ResultSet rs =null;
		
		try {
			con = Connect.getConnect();
			stmt = con.createStatement();
			String sql = "update javaBook set num = '"+cnum+"',title = '"+title+"',author = '"+author+"',genre = '"+genre+"' where num = '"+num+"';";
			stmt.executeUpdate(sql);
			} catch (SQLException e) {
				System.out.println("updatebook SQL ���� = " + e.getMessage());
			} finally {
				Connect.close(con, stmt,rs);
			}
		}
	
	
	public int ReturnBookNum(int num) {			// ���� ����Ҷ� �帣���ý� ��ȣ �ڵ����� ����
		Connection con = null;
		Statement stmt = null;
		ResultSet rs =null;
		int returnNum = 0;
		try {
			con = Connect.getConnect();
			stmt = con.createStatement();
			String sql = "select max(num) from javaBook where num like '"+num+"' '%';";
			rs= stmt.executeQuery(sql);
			while(rs.next()) {
				 String ptr = rs.getString("max(num)");
				 returnNum = Integer.parseInt(ptr);
			}
			} catch (SQLException e) {
				System.out.println("SQL ���� = " + e.getMessage());
			} finally {
				Connect.close(con, stmt,rs);
			}
		return returnNum+1;
		}
	
	public int MatchNum(int num) {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs =null;
		int returnNum = 1;
		try {
			con = Connect.getConnect();
			stmt = con.createStatement();
			String sql = "select num from javaBook";
			rs= stmt.executeQuery(sql);
			while(rs.next()) {
				 String ptr = rs.getString("num");
				 if (num == Integer.parseInt(ptr)) {
					 returnNum = 0;
					 break;
				 }
			}
			} catch (SQLException e) {
				System.out.println("SQL ���� = " + e.getMessage());
				return returnNum;
			} finally {
				Connect.close(con, stmt,rs);
			}
		
		return returnNum;
	}
	public int State(String num) {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs =null;
		int state = 10;
		try {
			con = Connect.getConnect();
			stmt = con.createStatement();
			String sql = "select state from javaBook where num = '"+ num +"'";			
			rs= stmt.executeQuery(sql);
			while(rs.next()) {
				state = rs.getInt("state");
			}
			return state;
		}
			 catch (SQLException e) {
				System.out.println("state SQL ���� = " + e.getMessage());
			} finally {
				Connect.close(con, stmt,rs);
			}
		
		return 0;
	}
	
	
	public void delete(String a) {		//book ����

		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;

		
		try {
			con = Connect.getConnect();
			stmt = con.createStatement();
			String sql = "delete from javaBook where num = '"+ a +"' ";
			stmt.executeUpdate(sql);
			
		} catch(SQLException e) {
			System.out.println("SQL ���� = " + e.getMessage());
		} finally {
			Connect.close(con, stmt, rs);
		}
		
	}

	
}
