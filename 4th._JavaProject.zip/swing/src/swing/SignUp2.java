package swing;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SignUp2 extends JFrame{
	
	JCheckBox []chk = new JCheckBox[9];
	String []str = {"ö��","����","��ȸ����","�ڿ�����","�������","����","���","����","����"};

	public SignUp2() {
		
		setTitle("SignUp");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		Container c = getContentPane();

		c.setLayout(null);
    
		JLabel tl = new JLabel("�߰������Է�");
		tl.setLocation(148,30);
        tl.setSize(80,40);
        c.add(tl);
        
        JPanel Panel1 = new JPanel();
        
        Panel1.setLayout(null);
        JLabel nml1 = new JLabel(" �� ��  : ");
        JTextField jtnm = new JTextField(10);
        
        nml1.setBounds(10,10,100,30);
        jtnm.setBounds(110,10,130,30);
        Panel1.add(nml1);
        Panel1.add(jtnm);
        
        JLabel agl1 = new JLabel(" �� ��  : ");
        JTextField jtag = new JTextField(10);
        
        agl1.setBounds(10,45,100,30);
        jtag.setBounds(110,45,50,30);
        Panel1.add(agl1);
        Panel1.add(jtag);
        
        
        
        Panel1.setBounds(10,80,400,120);
        
        JLabel sel1 = new JLabel(" �� �� : ");
        
        sel1.setBounds(10,80,100,30);
        Panel1.add(sel1);
        
        JRadioButton rd1 = new JRadioButton("��");
        JRadioButton rd2 = new JRadioButton("��");

        JRadioButton rd3 = new JRadioButton("");  //������ư�� �ʱ�ȭ�ϱ����� ������ ������ư
        
        // ���� ��ư�� �׷�ȭ �ϱ����� ��ü ����
        ButtonGroup groupRd = new ButtonGroup();
        
        // �׷쿡 ���� ��ư ���Խ�Ų��.
        groupRd.add(rd1);
        groupRd.add(rd2);
        groupRd.add(rd3);
        rd1.setBounds(115,160,50,30);
        rd2.setBounds(165,160,50,30);
               
        JPanel Panel2 = new JPanel();    //checkbox�� ���δ� panel2
        
        Panel2.setLayout(null);
        Panel2.setBounds(10,200,400,160);
        
        JLabel bk = new JLabel("���� �帣 :");
        bk.setBounds(10,0,100,30);
        chk[0] = new JCheckBox("ö��");
        for(int i=0;i<9;i++) {
        	chk[i]=new JCheckBox(str[i]);
        }
        int j=0,k=0;
        for (int i=0;i<9;i++) {
        	
        	chk[i].setBounds(105+j,k,80,30);
        	j+=80;
        	if (j>230) {
        		j=0;
        		k+=40;
        	}
       
        }
	    
	    Panel2.add(bk);
	    for (int i=0;i<9;i++) {
	    Panel2.add(chk[i]);
	    }
	    
	    
	    JPanel button = new JPanel();
        button.setBounds(-15,410,400,50);
        
        JButton nbutton = new JButton("ȸ������");
        JButton rbutton = new JButton("�����Է�");
        
        nbutton.addActionListener(new ButtonAction(){
        	public void actionPerformed(ActionEvent e) {
        		dispose();
        		new SignUp2();
        		
        	}
        });
        rbutton.addActionListener(new ButtonAction(){
        	public void actionPerformed(ActionEvent e) {
        		//jtnm.setText("");
        		jtnm.setText("");
        		jtag.setText("");
        		//rd1.setSelected(true);
        		rd3.setSelected(true);
        		for (int i=0;i<9;i++) {
        			chk[i].setSelected(false);
        		    }
        		
        	}
        });

        button.add(nbutton);
        button.add(rbutton);
        
        c.add(button);

        
        c.add(rd1);
        c.add(rd2);
        
        
        c.add(Panel1);
        c.add(Panel2);
        setSize(400, 600);//������ ������
        setVisible(true);
	}
public static void main(String[] args) {
	new SignUp2();
	}
}