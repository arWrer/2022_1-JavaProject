package swing;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class SignUp extends JFrame{
	public SignUp() {
		setTitle("SignUp");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		Container c = getContentPane();

		c.setLayout(null);
    
		JLabel tl = new JLabel("�⺻�����Է�");
		tl.setLocation(148,30);
        tl.setSize(80,40);
        c.add(tl);
        
        JPanel idPanel = new JPanel();
        
        idPanel.setLayout(null);
        JLabel idl1 = new JLabel(" ���̵�  : ");
        JTextField jtid = new JTextField(10);
        JButton idm = new JButton("�ߺ�Ȯ��"); 
        JLabel idl2 = new JLabel(" �ߺ��� ���̵��Դϴ� (���� �̺�Ʈó�� ����)");
        
        idl1.setBounds(10,10,100,30);
        jtid.setBounds(110,10,130,30);
        idm.setBounds(243,10,90,30);
        idl2.setBounds(107,42,130,30);
        idPanel.add(idl1);
        idPanel.add(jtid);
        idPanel.add(idm);
        idPanel.add(idl2);
        
        idPanel.setBounds(10,80,400,70);
    
        
        
        JPanel pwPanel1 = new JPanel();
        
        pwPanel1.setLayout(null);
        JLabel pwl1 = new JLabel(" ��й�ȣ  : ");
        JTextField jtpw = new JTextField(10);
        
        
        pwl1.setBounds(10,0,100,30);
        jtpw.setBounds(110,0,130,30);
        pwPanel1.add(pwl1);
        pwPanel1.add(jtpw);
        
        
        pwPanel1.setBounds(10,150,400,50);
        
        JPanel pwPanel2 = new JPanel();
        
        pwPanel2.setLayout(null);
        JLabel pwl2 = new JLabel(" ��й�ȣ Ȯ��  : ");
        JTextField jtpw2 = new JTextField(10);
        
        
        pwl2.setBounds(10,0,100,30);
        jtpw2.setBounds(110,0,130,30);
        pwPanel2.add(pwl2);
        pwPanel2.add(jtpw2);
        
        
        pwPanel2.setBounds(10,200,400,50);
        
        
        JPanel button = new JPanel();
        button.setBounds(-15,250,400,50);
        
        JButton nbutton = new JButton("����");
        JButton rbutton = new JButton("���� �Է�");
        
        nbutton.addActionListener(new ButtonAction(){
        	public void actionPerformed(ActionEvent e) {
        		dispose();
        		new SignUp2();
        		
        	}
        });

        button.add(nbutton);
        button.add(rbutton);
        
        
        c.add(idPanel);
        c.add(pwPanel1);
        c.add(pwPanel2);
        c.add(button);
       
        setSize(400, 600);//������ ������
		setVisible(true);
	}
	public static void main(String[] args) {
		new SignUp();
	}
}