package swing;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class SignUp2 extends JFrame{
	public SignUp2() {
		
		setTitle("SignUp");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
		Container c = getContentPane();

		c.setLayout(null);
    
		JLabel tl = new JLabel("�߰������Է�");
		tl.setLocation(148,30);
        tl.setSize(80,40);
        c.add(tl);
        
        JPanel Panel1 = new JPanel();
        
        Panel1.setLayout(null);
        JLabel nml1 = new JLabel(" �� ��  : ");
        JTextField jtnm = new JTextField(10);
        
        nml1.setBounds(10,10,100,30);
        jtnm.setBounds(110,10,130,30);
        Panel1.add(nml1);
        Panel1.add(jtnm);
        
        JLabel agl1 = new JLabel(" �� ��  : ");
        JTextField jtag = new JTextField(10);
        
        agl1.setBounds(10,45,100,30);
        jtag.setBounds(110,45,50,30);
        Panel1.add(agl1);
        Panel1.add(jtag);
        
        
        
        Panel1.setBounds(10,80,400,120);
        
        JLabel sel1 = new JLabel(" �� �� : ");
        
        sel1.setBounds(10,80,100,30);
        Panel1.add(sel1);
        
        JRadioButton rd1 = new JRadioButton("��");
        JRadioButton rd2 = new JRadioButton("��");
        
        // ���� ��ư�� �׷�ȭ �ϱ����� ��ü ����
        ButtonGroup groupRd = new ButtonGroup();
        
        // �׷쿡 ���� ��ư ���Խ�Ų��.
        groupRd.add(rd1);
        groupRd.add(rd2);
        rd1.setBounds(115,160,50,30);
        rd2.setBounds(165,160,50,30);
               
        JPanel Panel2 = new JPanel();    //checkbox�� ���δ� panel2
        
        Panel2.setLayout(null);
        Panel2.setBounds(10,200,400,160);
        Panel2.setBackground(Color.GREEN);
        
        JLabel bk = new JLabel("���� �帣 :");
        bk.setBounds(10,0,100,30);
        Checkbox chk1 = new Checkbox("ö��");
		Checkbox chk2 = new Checkbox("����");
		Checkbox chk3 = new Checkbox("��ȸ����");
		Checkbox chk4 = new Checkbox("�ڿ�����");
		Checkbox chk5 = new Checkbox("�������");
		Checkbox chk6 = new Checkbox("����");
		Checkbox chk7 = new Checkbox("���");
		Checkbox chk8 = new Checkbox("����");
		Checkbox chk9 = new Checkbox("����");
		
		chk1.setBounds(110,0,80,30);
	    chk2.setBounds(190,0,80,30);
	    chk3.setBounds(270,0,80,30);
	    chk4.setBounds(110,40,80,30);
	    chk5.setBounds(190,40,80,30);
	    chk6.setBounds(270,40,80,30);
	    chk7.setBounds(110,80,80,30);
	    chk8.setBounds(190,80,80,30);
	    chk9.setBounds(270,80,80,30);
	    
	    Panel2.add(bk);
	    Panel2.add(chk1);
	    Panel2.add(chk2);
	    Panel2.add(chk3);
	    Panel2.add(chk4);
	    Panel2.add(chk5);
	    Panel2.add(chk6);
	    Panel2.add(chk7);
	    Panel2.add(chk8);
	    Panel2.add(chk9);
	    
	    JPanel button = new JPanel();
        button.setBounds(-15,410,400,50);
        
        JButton nbutton = new JButton("ȸ������");
        JButton rbutton = new JButton("�����Է�");
        
        nbutton.addActionListener(new ButtonAction(){
        	public void actionPerformed(ActionEvent e) {
        		dispose();
        		new SignUp2();
        		
        	}
        });
        rbutton.addActionListener(new ButtonAction(){
        	public void actionPerformed(ActionEvent e) {
        		Panel1.removeAll();
        		//add your elements
        		validate();
        		
        	}
        });

        button.add(nbutton);
        button.add(rbutton);
        
        c.add(button);

        
        c.add(rd1);
        c.add(rd2);
        
        
        c.add(Panel1);
        c.add(Panel2);
        setSize(400, 600);//������ ������
        setVisible(true);
	}
public static void main(String[] args) {
	new SignUp2();
	}
}